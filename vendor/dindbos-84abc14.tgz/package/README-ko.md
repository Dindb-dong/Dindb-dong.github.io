<p align="center">
  <picture>
    <source media="(prefers-color-scheme: dark)" srcset="docs/assets/brand/dindbos-mark.png">
    <img src="docs/assets/brand/dindbos-lockup.png" alt="DindbOS" height="96">
  </picture>
</p>

<h1 align="center">DindbOS</h1>
<p align="center">웹페이지에 데스크톱을 넣고, 내 앱을 올리세요.</p>
<p align="center"><a href="README.md">English</a> · <strong>한국어</strong></p>
<p align="center"><a href="https://dindb-dong.github.io/">데모</a> · <a href="INSTALL.md">설치</a> · <a href="docs/react-apps.md">앱 만들기</a> · <a href="docs/customization.md">커스터마이징</a></p>

<p align="center"><img src="docs/assets/desktop.png" alt="최신 Files·Notes·Calculator를 실행한 DindbOS 데스크톱" width="1280"></p>

포트폴리오, 인터랙티브 프로젝트, 웹사이트의 일부 페이지를 macOS풍 데스크톱으로 만드는 SDK입니다. React 컴포넌트나 JavaScript 함수를 앱으로 등록하고, 테마와 데스크톱 UI를 바꿀 수 있습니다. 창·포커스·파일·실행 상태는 런타임이 관리합니다.

[개인 포트폴리오](https://dindb-dong.github.io/)에서도 실제로 사용합니다. Applications·Files·Reminders·Calendar·Photos·Music·Clock·TextEdit·Viewer·Terminal·Calculator·Activity Monitor·Settings를 선택해서 사용할 수 있습니다. [기본 앱 기능과 저장 위치](docs/builtin-apps.md).

> 아래 예제는 dindbos 0.2.0 이상을 사용합니다. [포트폴리오 데모](https://dindb-dong.github.io/)는 SDK를 사용하는 별도 프로젝트이므로 버전이 다를 수 있습니다. 소스 빌드는 [INSTALL.md](INSTALL.md)를 참고하세요.

## 데스크톱에서 할 수 있는 일

- **창과 메뉴:** 창 이동·크기 변경·최소화·복원, 활성 앱에 맞는 메뉴를 제공합니다. 여러 데스크톱을 각각 독립된 영역에 넣을 수 있습니다.
- **익숙한 파일 탐색:** 탭 순서 변경·새 창 분리, 사이드바 즐겨찾기·순서 변경, 인라인 이름 편집, 다음으로 열기, 문서 미리보기, ZIP 압축과 색 태그를 지원합니다.
- **내 사이트에 맞게:** Settings에서 배경과 화면 모드를 바꾸고 Dock을 조정하세요. 테마 토큰과 렌더 슬롯으로 UI를 교체할 수 있고, React 앱은 호스트 Context를 유지합니다.

기본 진입 시 안내 창 없이 데스크톱이 열립니다. 아래 사진은 실제 기본 앱을 실행하고 촬영용 메모를 입력해 찍은 화면이며, 합성한 UI가 아닙니다.

<table>
  <tr>
    <td><img src="docs/assets/applications.png" alt="설치된 앱 아이콘과 검색 기능이 있는 Applications" width="600"></td>
    <td><img src="docs/assets/files-context-menu.png" alt="다음으로 열기 하위 메뉴가 표시된 Files 우클릭 메뉴" width="600"></td>
  </tr>
  <tr><td align="center">설치한 앱을 한곳에서</td><td align="center">파일 작업과 실제 앱 연결</td></tr>
  <tr>
    <td><img src="docs/assets/settings-wallpaper.png" alt="배경 미리보기와 갤러리가 있는 Settings" width="600"></td>
    <td><img src="docs/assets/control-center.png" alt="굴절 유리 재질의 제어센터" width="600"></td>
  </tr>
  <tr><td align="center">배경화면과 화면 모드</td><td align="center">제어센터와 Liquid Glass</td></tr>
</table>

<details>
<summary>다크 모드·좁은 화면·기본 데스크톱 보기</summary>

![다크 모드 데스크톱](docs/assets/desktop-dark.png)
<p align="center"><img src="docs/assets/mobile.png" alt="좁은 다크 모드 데스크톱에서 실행한 Notes" width="260"></p>

![안내 창 없이 시작하는 기본 데스크톱](docs/assets/desktop-empty.png)

</details>

## 시작하기

배포된 패키지로 React 프로젝트를 생성합니다:

```sh
npm exec --package=dindbos@latest -- create-dindbos my-desktop --template react --yes
cd my-desktop
npm install
npm run dev
```

JavaScript 프로젝트는 `--template vanilla`로 생성합니다. CLI는 `dindbos` 패키지 안에 포함됩니다. 기존 파일을 기본적으로 덮어쓰지 않고, 의존성도 자동 설치하지 않습니다.

## React 앱 추가

기존 프로젝트에서는 npm으로 설치한 뒤 아래 예제를 사용하세요:

```sh
npm install dindbos
```

```jsx
import React, { useState } from "react";
import { DindbOSDesktop, DindbOSApp } from "dindbos/react";
import "dindbos/styles.css";

function Hello() {
  const [count, setCount] = useState(0);
  return <button onClick={() => setCount(count + 1)}>클릭 {count}회</button>;
}

export default function DesktopPage() {
  return <DindbOSDesktop
    style={{ height: 640 }}
    storage={{ name: "my-desktop" }}
    theme={{ mode: "system", accent: "#287a58", wallpaper: "meadow", dockSize: 52 }}
    builtins={{ includePortfolio: false }}
    launch={["hello"]}
  >
    <DindbOSApp id="hello" name="Hello" icon="app" pinned desktop>
      <Hello />
    </DindbOSApp>
  </DindbOSDesktop>;
}
```

Hello가 창으로 열리고 데스크톱과 Dock에 아이콘이 생깁니다. 최소화·복원 시 상태가 유지되고, 닫은 뒤 다시 열면 새 인스턴스가 됩니다. 호스트의 React Context는 앱 안에서도 유지됩니다. 컨테이너 높이를 지정하고, 독립적인 데스크톱에는 서로 다른 storage name을 사용하세요.

기존 JavaScript `createAndBootDindbOS`와 `render({ content, os, window, context })` 방식도 유지합니다. 함수·클래스 앱은 `defineApp`으로 정의합니다. [첫 앱](docs/first-app.md) · [React 수명주기](docs/react-apps.md).

## 바꿀 수 있는 것

| 대상 | 방법 |
| --- | --- |
| 밝기·배경·강조색·Dock 크기 | `theme`, 런타임의 `setAppearance()` |
| 앱 내용과 아이콘 | React 컴포넌트·함수·클래스 앱 |
| 메뉴바·Dock·데스크톱·창 장식 | `ui.slots` 렌더러 |
| 기본 앱 구성 | include/exclude 후 사용자 앱 등록 |
| 초기 파일·저장소·실행 앱 | 호스트 설정 |

실행·권한·파일·창 상태의 소유권은 런타임에 둡니다. 신뢰된 호스트 앱과 설치형 패키지 앱의 권한 경계를 합치지 않습니다. [커스터마이징](docs/customization.md).

## CLI와 에이전트

배포된 CLI로 프로젝트를 생성하고 관리합니다:

```sh
npm exec --package=dindbos@latest -- create-dindbos studio --template react --yes --json
npm exec --package=dindbos@latest -- create-dindbos add app notes --root studio --json
npm exec --package=dindbos@latest -- create-dindbos doctor studio --json
```

`--dry-run`은 파일을 쓰지 않고 결과를 보여줍니다. `--force`가 있어야 덮어쓰기를 허용합니다. 생성된 `src/apps/index.js`의 등록 마커가 없으면 앱 추가를 중단합니다. doctor는 로컬 프로젝트 구조를 확인하며 배포나 외부 서비스 정상 동작까지 증명하지 않습니다.

에이전트에게 전달할 요청:

> SOURCE에서 dindbOS를 설치해줘. INSTALL.md와 docs/agent-guide.md를 읽고 기존 파일과 라우트를 보존해. 컨테이너 하나에 데스크톱을 넣고 DindbOSApp으로 React 앱을 추가해. 공개 API로 테마를 바꾸고, 패키지 출처·빌드·앱 실행·키보드·정리를 확인해. 확인한 항목을 보고하고 게시·배포·push는 하지 마.

SOURCE를 저장소 또는 빌드한 tarball 경로로 바꾸세요. 생성 프로젝트에는 `AGENTS.md`가 포함됩니다.

## 예제와 지원 범위

**현재 브라우저 동작·화면 검증은 macOS의 Google Chrome에서 수행했습니다.** 좁은 화면·모바일 레이아웃은 Chrome 에뮬레이션으로 확인했습니다. Safari·Firefox·실제 모바일 기기는 아직 검증하지 않았으며, 대체 표시 구현이 검증된 지원을 뜻하지는 않습니다.

[React/Vite](examples/react-vite), [Vanilla/Vite](examples/vanilla-vite), [Next.js](examples/next-client), [Astro](examples/astro-island) 예제가 있습니다. [배포 안내](docs/deployment.md)도 참고하세요.

브라우저 저장소는 권한·용량·삭제 정책에 영향을 받습니다. 중요한 파일은 내보내세요. 클립보드·로컬 폴더 기능은 브라우저 지원과 권한에 따라 달라집니다. Browser.app의 외부 사이트 탐색은 선택적인 [browser companion](docs/browserd.md)이 필요할 수 있습니다. 기본 데스크톱은 companion이나 Service Worker 없이 실행됩니다.

## 개발·기여

[버그 제보](https://github.com/Dindb-dong/dindbos/issues/new?template=bug_report.md) · [기능 제안](https://github.com/Dindb-dong/dindbos/issues/new?template=feature_request.md) · [PR 템플릿](.github/PULL_REQUEST_TEMPLATE.md) · [기여 안내](CONTRIBUTING.md). 다른 브라우저의 문제도 제보할 수 있습니다. 재현 순서와 브라우저 버전을 함께 적어주세요.

```sh
npm ci
npm run dev
npm run check
npm run build:sdk
npm run build
```

변경 영역의 smoke 검사를 실행하고 실제 화면과 동작을 확인하세요. [기여 안내](CONTRIBUTING.md) · [개발자 문서](docs/developer-guide.md).

## 프로젝트 로고

<p><img src="docs/assets/brand/dindbos-mark.png" alt="DindbOS 프로젝트 로고" width="88"></p>

[투명 로고](docs/assets/brand/dindbos-mark.png) · [투명 lockup](docs/assets/brand/dindbos-lockup.png). 전달받은 파랑·청록 계열 원본을 바탕으로 외곽 배경과 로고 안쪽의 빈 영역을 투명화했습니다. [아트워크와 촬영 출처](docs/assets/README.md).

## 라이선스

[MIT](LICENSE). 아이콘·SVG는 프로젝트의 원본 아트워크이며 데모 배경은 이 프로젝트를 위해 생성했습니다. [아트워크 출처](docs/assets/README.md)를 참고하세요. 연결된 외부 자료와 프로젝트에는 각각의 라이선스가 적용됩니다.
